#pragma once

#define I2S_BUFFER_COUNT 30
#define I2S_BUFFER_SIZE 384