
Integration to different external audio libraries