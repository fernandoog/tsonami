
Analog audio output using PWM