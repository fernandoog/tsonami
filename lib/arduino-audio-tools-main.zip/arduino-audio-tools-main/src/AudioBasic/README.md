
This directory contains some common basic classes which are used accress the framework