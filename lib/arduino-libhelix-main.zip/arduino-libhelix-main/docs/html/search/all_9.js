var searchData=
[
  ['setdelay_0',['setDelay',['../classlibhelix_1_1_common_helix.html#ac62f121f7be3dc1b1cf80d983319efe9',1,'libhelix::CommonHelix']]],
  ['setmaxframesize_1',['setMaxFrameSize',['../classlibhelix_1_1_common_helix.html#a28a81c90298d1dbc107b2b799ce3fed2',1,'libhelix::CommonHelix']]],
  ['setmaxpcmsize_2',['setMaxPCMSize',['../classlibhelix_1_1_common_helix.html#ad81283a33815f2c1b915a4c00393e22d',1,'libhelix::CommonHelix']]],
  ['synchronizeframe_3',['synchronizeFrame',['../classlibhelix_1_1_common_helix.html#a33ae215e20b7ece5cadf1a0b7098aff9',1,'libhelix::CommonHelix']]]
];
