var searchData=
[
  ['maxframesize_0',['maxFrameSize',['../classlibhelix_1_1_a_a_c_decoder_helix.html#acffadea654dec9e804581b0cb5f42cd3',1,'libhelix::AACDecoderHelix::maxFrameSize()'],['../classlibhelix_1_1_common_helix.html#a5b0fff8a3e335fe2ae5d7e2ed744cc15',1,'libhelix::CommonHelix::maxFrameSize()'],['../classlibhelix_1_1_m_p3_decoder_helix.html#a2d5ccd25d280d7e65f26d3c04f4642b6',1,'libhelix::MP3DecoderHelix::maxFrameSize()']]],
  ['maxpcmsize_1',['maxPCMSize',['../classlibhelix_1_1_a_a_c_decoder_helix.html#a273fb7ceca9e4e213c5e7722c77cc461',1,'libhelix::AACDecoderHelix::maxPCMSize()'],['../classlibhelix_1_1_common_helix.html#a0c78a63c35669f2e83cd6d51b211248a',1,'libhelix::CommonHelix::maxPCMSize()'],['../classlibhelix_1_1_m_p3_decoder_helix.html#aae551cdc3657a430e5d35d67f1538f2c',1,'libhelix::MP3DecoderHelix::maxPCMSize()']]],
  ['mp3decoderhelix_2',['MP3DecoderHelix',['../classlibhelix_1_1_m_p3_decoder_helix.html',1,'libhelix']]]
];
